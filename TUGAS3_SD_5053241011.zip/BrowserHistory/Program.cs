
using System;

namespace Solution.BrowserHistory
{
    public class Halaman
    {
        public string URL { get; set; }

        public Halaman(string url)
        {
            URL = url;
        }
    }

    public class Node
    {
        public Halaman Data;
        public Node Next;

        public Node(Halaman data)
        {
            Data = data;
            Next = null;
        }
    }

    public class Stack
    {
        private Node top;

        public void Push(Halaman halaman)
        {
            Node newNode = new Node(halaman);
            newNode.Next = top;
            top = newNode;
        }

        public Halaman Pop()
        {
            if (top == null) return null;
            Halaman temp = top.Data;
            top = top.Next;
            return temp;
        }

        public Halaman Peek()
        {
            return top?.Data;
        }

        public bool IsEmpty()
        {
            return top == null;
        }

        public void PrintAll()
        {
            Node current = top;
            int i = 1;
            while (current != null)
            {
                Console.WriteLine($"{i++}. {current.Data.URL}");
                current = current.Next;
            }
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            Stack history = new Stack();
            void KunjungiHalaman(string url)
            {
                Console.WriteLine($"Mengunjungi halaman: {url}");
                history.Push(new Halaman(url));
            }

            string Kembali()
            {
                history.Pop();
                return history.Peek()?.URL ?? "Tidak ada halaman sebelumnya.";
            }

            string LihatHalamanSaatIni()
            {
                return history.Peek()?.URL ?? "Tidak ada halaman.";
            }

            KunjungiHalaman("google.com");
            KunjungiHalaman("example.com");
            KunjungiHalaman("stackoverflow.com");
            Console.WriteLine("Halaman saat ini: " + LihatHalamanSaatIni());
            Console.WriteLine("Kembali ke halaman sebelumnya...");
            Console.WriteLine("Halaman saat ini: " + Kembali());
            Console.WriteLine("Menampilkan history:");
            history.PrintAll();
        }
    }
}
