
using System;
using System.Collections.Generic;
using System.Linq;

namespace Solution.Palindrome
{
    public static class PalindromeChecker
    {
        public static bool CekPalindrom(string input)
        {
            string cleaned = new string(input.ToLower().Where(char.IsLetter).ToArray());
            Stack<char> stack = new Stack<char>();
            foreach (char c in cleaned)
            {
                stack.Push(c);
            }

            foreach (char c in cleaned)
            {
                if (stack.Pop() != c)
                    return false;
            }
            return true;
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            string s1 = "Kasur ini rusak";
            string s2 = "Ibu Ratna antar ubi";
            string s3 = "Hello World";

            Console.WriteLine($""{s1}" → {PalindromeChecker.CekPalindrom(s1)}");
            Console.WriteLine($""{s2}" → {PalindromeChecker.CekPalindrom(s2)}");
            Console.WriteLine($""{s3}" → {PalindromeChecker.CekPalindrom(s3)}");
        }
    }
}
